if __name__ == '__main__':
    # TODO
    # Inspirez-vous du fichier de test pour l'utilisation de scratch_net

    # Création et initialisation des poids
    # w1 = ...
    # ...

    for i in range(10):
        # Création d'un input random

        # Création du réseau à partir des poids w créés hors de la boucle

        # Backprop

        # Mise-à-jour

        # Cleanup: mettre les gradients des poids à None avec
        # w1.gradient = None
        pass
